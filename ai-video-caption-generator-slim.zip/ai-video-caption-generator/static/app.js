'use strict';
/* app.js - user interface: upload, live preview, controls, export */

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const sleep = ms => new Promise(r => setTimeout(r, ms));
const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const st = { id: null, name: 'video', vw: 1280, vh: 720, dur: 0, segments: [], caps: [], dispH: 360, drag: false, offset: 0 };
const video = $('#video'), stage = $('#stage'), cap = $('#cap');

const LANGS = [['auto', 'Auto-detect'], ['en', 'English'], ['ur', 'Urdu'], ['hi', 'Hindi'], ['ar', 'Arabic'], ['fa', 'Persian'],
  ['pa', 'Punjabi'], ['bn', 'Bengali'], ['tr', 'Turkish'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'],
  ['it', 'Italian'], ['pt', 'Portuguese'], ['ru', 'Russian'], ['zh', 'Chinese'], ['ja', 'Japanese'], ['ko', 'Korean'], ['id', 'Indonesian']];
$('#lang').innerHTML = LANGS.map(([v, n]) => `<option value="${v}">${n}</option>`).join('');

/* ---------------- controls (generated from this list) ---------------- */
const CTL = {
  style: [
    { k: 'font', t: 'select', l: 'Font', o: FONTS },
    { k: 'size', t: 'range', l: 'Text size', min: 1, max: 20, step: 0.1 },
    { k: 'bold', t: 'check', l: 'Bold' }, { k: 'italic', t: 'check', l: 'Italic' }, { k: 'upper', t: 'check', l: 'UPPERCASE' },
    { k: 'color', t: 'color', l: 'Text color' }, { k: 'hi', t: 'color', l: 'Highlight color' },
    { k: 'outlineColor', t: 'color', l: 'Outline color' },
    { k: 'outline', t: 'range', l: 'Outline thickness', min: 0, max: 10, step: 0.5 },
    { k: 'shadow', t: 'range', l: 'Shadow', min: 0, max: 8, step: 0.5 },
    { k: 'spacing', t: 'range', l: 'Letter spacing (not for Urdu/Arabic)', min: -2, max: 20, step: 0.5 },
    { k: 'box', t: 'check', l: 'Background box' }, { k: 'boxColor', t: 'color', l: 'Box color' },
    { k: 'boxOpacity', t: 'range', l: 'Box opacity', min: 0, max: 100, step: 5, u: '%' },
    { reset: true },
    { note: 'For Urdu / Arabic / Hindi use Arial, Tahoma or Segoe UI. They contain those letters.' },
  ],
  motion: [{ anims: true },
    { k: 'maxWords', t: 'range', l: 'Words per caption (0 = whole sentence)', min: 0, max: 10, step: 1 },
    { note: 'Short captions (2-4 words) look best with "Word highlight". "Word by word" shows one word at a time.' }],
  pos: [
    { presets: true },
    { k: 'x', t: 'range', l: 'Horizontal position', min: 0, max: 100, step: 1, u: '%' },
    { k: 'y', t: 'range', l: 'Vertical position', min: 0, max: 100, step: 1, u: '%' },
    { k: 'width', t: 'range', l: 'Text width (when to wrap lines)', min: 30, max: 100, step: 1, u: '%' }],
};

function ctlHTML(c) {
  if (c.reset) return `<button class="ghost" id="resetStyle" style="width:100%">↺ Reset to template style</button>`;
  if (c.note) return `<p class="note">${c.note}</p>`;
  if (c.anims) return `<div class="anims">${ANIMS.map(a => `<button class="anim" data-anim="${a.id}"><b>${a.icon}</b>${a.name}</button>`).join('')}</div>`;
  if (c.presets) return `<div class="presets"><button class="ghost" data-y="12">⬆ Top</button><button class="ghost" data-y="50">⬌ Middle</button><button class="ghost" data-y="86">⬇ Bottom</button></div>`;
  const id = 'c_' + c.k;
  if (c.t === 'select') return `<label class="ctl">${c.l}<select data-k="${c.k}">${c.o.map(o => `<option>${o}</option>`).join('')}</select></label>`;
  if (c.t === 'range') return `<label class="ctl"><div class="top2"><span>${c.l}</span><span class="val" data-v="${c.k}"></span></div><input type="range" data-k="${c.k}" min="${c.min}" max="${c.max}" step="${c.step}"></label>`;
  if (c.t === 'check') return `<label class="ctl half ctl-check"><input type="checkbox" data-k="${c.k}">${c.l}</label>`;
  return `<label class="ctl half ctl-color"><span>${c.l}</span><input type="color" data-k="${c.k}"></label>`;
}
for (const [name, list] of Object.entries(CTL)) $('#pane-' + name).innerHTML = list.map(ctlHTML).join('');

function syncInputs() {
  $$('[data-k]').forEach(el => {
    const v = S[el.dataset.k];
    if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
  });
  const units = {}; Object.values(CTL).flat().forEach(c => { if (c.k) units[c.k] = c.u || ''; });
  $$('[data-v]').forEach(el => { el.textContent = S[el.dataset.v] + units[el.dataset.v]; });
  $$('.anim').forEach(b => b.classList.toggle('on', b.dataset.anim === S.anim));
  $$('.tpl').forEach(b => b.classList.toggle('on', +b.dataset.i === st.tpl));
}

document.addEventListener('input', e => {
  const k = e.target.dataset && e.target.dataset.k;
  if (!k) return;
  const el = e.target;
  S[k] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? parseFloat(el.value) : el.value;
  if (k === 'maxWords') rebuild();
  st.tpl = -1;
  syncInputs();
});
document.addEventListener('click', e => {
  const a = e.target.closest('.anim'); if (a) { S.anim = a.dataset.anim; st.tpl = -1; syncInputs(); }
  const p = e.target.closest('[data-y]'); if (p) { S.y = +p.dataset.y; S.x = 50; syncInputs(); }
});

/* ---------------- tabs & templates ---------------- */
$('#tabs').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  $$('#tabs button').forEach(x => x.classList.toggle('on', x === b));
  $$('.pane').forEach(p => p.classList.toggle('hidden', p.id !== 'pane-' + b.dataset.tab));
});

const MINI_H = 260, MY_KEY = 'captionGeneratorMyStyles';
let MY = []; try { MY = JSON.parse(localStorage.getItem(MY_KEY) || '[]'); } catch (e) { MY = []; }
const saveMy = () => { try { localStorage.setItem(MY_KEY, JSON.stringify(MY)); } catch (e) {} };
const hexA = (hex, a) => { const h = hex.replace('#', ''); return `rgba(${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)},${a})`; };

/* a template card = a real mini caption drawn with that template's font, colors, outline, box and animation (hover) */
function miniCard(name, s, attrs, extra = '') {
  const fp = clamp(s.size / 100 * MINI_H * EMK, 10, 22), k = MINI_H / 1080;
  const w = s.upper ? ['YOUR', 'CAPTION'] : ['Your', 'caption'];
  const css = `font-family:'${s.font}',Arial,sans-serif;font-size:${fp}px;font-weight:${s.bold ? 700 : 400};font-style:${s.italic ? 'italic' : 'normal'};color:${s.color};` +
    (s.box ? `background:${hexA(s.boxColor, s.boxOpacity / 100)};padding:2px 9px;border-radius:5px;`
           : `-webkit-text-stroke:${clamp(s.outline * k * 3.2, 0, 4)}px ${s.outlineColor};text-shadow:${s.shadow * k * 1.5}px ${s.shadow * k * 1.5}px 0 rgba(0,0,0,.55);`);
  const an = (ANIMS.find(a => a.id === s.anim) || ANIMS[0]).name;
  return `<div class="tpl" ${attrs}><div class="mini a-${s.anim}" style="--c:${s.color};--hi:${s.hi}"><span class="mt" style="${css}"><span class="w w1">${w[0]}</span> <span class="w w2">${w[1]}</span></span></div><small>${esc(name)}<em>${an}</em></small>${extra}</div>`;
}

function renderTemplates(filter = '') {
  const q = filter.trim().toLowerCase();
  const mine = MY.map((m, j) => ({ m, j })).filter(x => x.m.name.toLowerCase().includes(q));
  const found = TEMPLATES.map((t, i) => ({ t, i })).filter(x => x.t.name.toLowerCase().includes(q));
  $('#pane-templates').innerHTML =
    '<button class="ghost" id="saveStyle" style="width:100%;margin-bottom:12px">💾 Save current look as my template</button>' +
    (mine.length ? '<p class="note" style="margin-bottom:8px">My templates</p><div class="tpls">' +
      mine.map(({ m, j }) => miniCard(m.name, { ...BASE, ...m.style }, `data-my="${j}"`, `<button class="del" data-del="${j}" title="Delete">×</button>`)).join('') +
      '</div><p class="note" style="margin:14px 0 8px">All styles · hover to see the animation</p>' : '<p class="note" style="margin-bottom:8px">Hover a style to see its animation</p>') +
    '<div class="tpls">' + found.map(({ t, i }) => miniCard(t.name, t.style, `data-i="${i}"`)).join('') +
    (found.length ? '' : '<p class="empty">No matching styles. Try another keyword.</p>') + '</div>';
  syncInputs();
}
renderTemplates();
$('#templateSearch').addEventListener('input', e => renderTemplates(e.target.value));
$('#pane-templates').addEventListener('click', e => {
  const again = () => renderTemplates($('#templateSearch').value);
  if (e.target.id === 'saveStyle') { const n = prompt('Name for your template?', 'My style ' + (MY.length + 1)); if (n) { MY.push({ name: n.slice(0, 24), style: { ...S } }); saveMy(); again(); } return; }
  const d = e.target.closest('[data-del]'); if (d) { MY.splice(+d.dataset.del, 1); saveMy(); again(); return; }
  const c = e.target.closest('.tpl'); if (!c) return;
  const mine = c.dataset.my !== undefined;
  S = { ...BASE, ...(mine ? MY[+c.dataset.my].style : TEMPLATES[+c.dataset.i].style) };
  st.base = { ...S }; st.tpl = mine ? -1 : +c.dataset.i;
  rebuild(); syncInputs();
});
st.tpl = 0; st.base = { ...S };
document.addEventListener('click', e => { if (e.target.id === 'resetStyle') { S = { ...(st.base || TEMPLATES[0].style) }; rebuild(); syncInputs(); } });

/* ---------------- video loading ---------------- */
const drop = $('#drop'), fileInput = $('#file');
drop.addEventListener('click', () => fileInput.click());
drop.addEventListener('keydown', e => { if (e.key === 'Enter') fileInput.click(); });
['dragover', 'dragenter'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => { if (e.dataTransfer.files[0]) upload(e.dataTransfer.files[0]); });
fileInput.addEventListener('change', () => { if (fileInput.files[0]) upload(fileInput.files[0]); });
$('#newBtn').addEventListener('click', () => location.reload());

function say(sel, msg, kind) { const el = $(sel); el.textContent = msg || ''; el.className = 'status' + (kind ? ' ' + kind : ''); }

async function upload(file) {
  say('#uploadMsg', 'Uploading and preparing your video...');
  try {
    const fd = new FormData(); fd.append('video', file);
    const r = await fetch('/api/upload', { method: 'POST', body: fd });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Upload failed');
    st.id = j.id; st.name = j.name;
    video.src = '/media/' + j.id;
    await new Promise((ok, bad) => { video.onloadedmetadata = ok; video.onerror = () => bad(new Error('Your browser cannot play this video.')); });
    st.vw = video.videoWidth; st.vh = video.videoHeight; st.dur = video.duration;
    drop.classList.add('hidden'); $('#workspace').classList.remove('hidden'); $('#newBtn').classList.remove('hidden');
    $('#genBtn').disabled = false;
    fitStage();
  } catch (err) { say('#uploadMsg', err.message, 'err'); }
}

function fitStage() {
  const wrap = $('.stage-wrap'), ar = st.vw / st.vh;
  const w = Math.min(wrap.clientWidth || 640, window.innerHeight * 0.62 * ar);
  stage.style.width = w + 'px'; stage.style.height = (w / ar) + 'px';
  st.dispH = w / ar;
}
window.addEventListener('resize', () => st.id && fitStage());

/* ---------------- player ---------------- */
const fmt = t => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
$('#playBtn').addEventListener('click', () => video.paused ? video.play() : video.pause());
video.addEventListener('click', () => video.paused ? video.play() : video.pause());
video.addEventListener('play', () => $('#playBtn').textContent = '❚❚');
video.addEventListener('pause', () => $('#playBtn').textContent = '▶');
$('#seek').addEventListener('input', e => { video.currentTime = e.target.value / 1000 * st.dur; });
video.addEventListener('seeked', () => { if (st.caps.length) paint(st.caps.find(x => video.currentTime >= x.start && video.currentTime < x.end), video.currentTime); });
document.addEventListener('keydown', e => {
  if (e.code === 'Space' && st.id && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); $('#playBtn').click(); }
});

/* ---------------- live preview ---------------- */
const SAMPLE = buildCaptions([{ start: 0, end: 2.8, text: '', words: 'Your captions will look like this'.split(' ').map((w, i) => ({ w, s: i * 0.4, e: i * 0.4 + 0.38 })) }], 0);

function lineHTML(f) {
  const word = (w) => (w.i === f.hi) ? `<span style="color:${S.hi}">${esc(w.w)}</span>` : esc(w.w);
  let lines;
  if (f.n != null) {                         // typewriter: visible part + invisible rest keeps the layout stable
    let left = f.n;
    lines = f.lines.map(l => l.map(w => w.w).join(' ')).map(txt => {
      const vis = txt.slice(0, clamp(left, 0, txt.length)); left -= txt.length + 1;
      return esc(vis) + `<i style="opacity:0;font-style:inherit">${esc(txt.slice(vis.length))}</i>`;
    });
  } else lines = f.lines.map(l => l.map(word).join(' '));
  return lines.map(l => `<span class="ln" dir="auto"><span class="bg">${l}</span></span>`).join('');
}

function paint(c, t) {
  const f = c && frameAt(c, t, st.vw, st.vh);
  if (!f) { cap.style.visibility = 'hidden'; handle.classList.add('hidden'); return; }
  const k = st.dispH / st.vh;                         // video pixels -> screen pixels
  const sizePx = S.size / 100 * st.vh;
  const pad = sizePx * 0.22 * k;
  const o = S.outline * st.vh / 1080 * k, sh = S.shadow * st.vh / 1080 * k;
  const boxRGBA = (() => { const h = S.boxColor.replace('#', ''); return `rgba(${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)},${S.boxOpacity / 100})`; })();
  Object.assign(cap.style, {
    visibility: 'visible', left: S.x + '%', top: S.y + '%', width: S.width + '%',
    fontFamily: `"${S.font}", Arial, sans-serif`, fontSize: sizePx * EMK * k + 'px', lineHeight: sizePx * k + 'px',
    fontWeight: S.bold ? 700 : 400, fontStyle: S.italic ? 'italic' : 'normal', color: S.color, letterSpacing: (S.spacing || 0) * st.vh / 1080 * k + 'px',
    webkitTextStroke: S.box || o <= 0 ? '0' : `${o * 2}px ${S.outlineColor}`,
    textShadow: !S.box && sh > 0 ? `${sh}px ${sh}px 0 rgba(0,0,0,.55)` : 'none',
    opacity: f.o, transform: `translate(-50%,-50%) translateY(${f.dy * k}px) scale(${f.sc})`,
  });
  cap.innerHTML = lineHTML(f);
  if (S.box) $$('#cap .bg').forEach(b => { b.style.background = boxRGBA; b.style.padding = `${pad * 0.35}px ${pad}px`; });
  placeHandle();
}

function tick() {
  requestAnimationFrame(tick);
  if (!st.id) return;
  const t = video.currentTime;
  if (!st.drag) $('#seek').value = st.dur ? t / st.dur * 1000 : 0;
  $('#timeLabel').textContent = `${fmt(t)} / ${fmt(st.dur || 0)}`;
  if (!st.caps.length) {                              // sample preview follows the playhead and freezes on pause
    paint(SAMPLE[0], video.paused ? t % 3.4 : t % 3.4);
    return;
  }
  const c = st.caps.find(x => t >= x.start && t < x.end);
  paint(c, t); // never substitute a future/previous caption while paused or between cues
}
requestAnimationFrame(tick);

/* drag the caption to move it */
cap.addEventListener('pointerdown', e => { st.drag = true; cap.classList.add('drag'); cap.setPointerCapture(e.pointerId); });
cap.addEventListener('pointermove', e => {
  if (!cap.classList.contains('drag')) return;
  const r = stage.getBoundingClientRect();
  S.x = Math.round(clamp((e.clientX - r.left) / r.width * 100, 0, 100));
  S.y = Math.round(clamp((e.clientY - r.top) / r.height * 100, 0, 100));
  if (Math.abs(S.x - 50) <= 2) S.x = 50;
  $('#guide').classList.toggle('hidden', S.x !== 50);
  syncInputs();
});
cap.addEventListener('pointerup', () => { st.drag = false; cap.classList.remove('drag'); $('#guide').classList.add('hidden'); });

/* ---------------- generate captions ---------------- */
function rebuild() {
  st.caps = buildCaptions(st.segments, S.maxWords);
  const o = st.offset; if (o) st.caps = st.caps.map(c => ({ ...c, start: Math.max(0, c.start + o), end: Math.max(0.15, c.end + o), words: c.words.map(w => ({ ...w, s: w.s + o, e: w.e + o })) }));
  $('#exportBtn').disabled = $('#srtBtn').disabled = $('#assBtn').disabled = $('#txtBtn').disabled = !st.caps.length;
}

async function poll(kind, onTick) {
  for (;;) {
    await sleep(800);
    const r = await (await fetch(`/api/status/${st.id}/${kind}`)).json();
    onTick(r);
    if (r.state === 'done' || r.state === 'error') return r;
  }
}

$('#genBtn').addEventListener('click', async () => {
  const btn = $('#genBtn'); btn.disabled = true; $('#genBar').classList.remove('hidden'); say('#genMsg', 'Starting...');
  try {
    const body = { id: st.id, model: $('#model').value, language: $('#lang').value, task: document.querySelector('input[name=task]:checked').value };
    const r = await fetch('/api/transcribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!r.ok) throw new Error((await r.json()).error);
    const res = await poll('transcribe', s => say('#genMsg', s.message));
    if (res.state === 'error') throw new Error(res.message);
    st.segments = res.segments;
    if (!st.segments.length) { say('#genMsg', 'No speech was found in this video.', 'err'); return; }
    rebuild(); renderWords();
    say('#genMsg', `Done! ${st.segments.length} caption${st.segments.length === 1 ? "" : "s"} · language: ${res.language || 'unknown'}. Now pick a template ↓`, 'ok');
    video.currentTime = 0;
  } catch (err) { say('#genMsg', err.message, 'err'); }
  finally { btn.disabled = false; $('#genBar').classList.add('hidden'); }
});

/* ---------------- edit words ---------------- */
const offHTML = () => `<label class="ctl" style="width:100%;margin-bottom:10px"><div class="top2"><span>Shift caption timing (if out of sync)</span><span class="val" id="offVal">${st.offset.toFixed(2)}s</span></div><input type="range" data-off min="-2" max="2" step="0.05" value="${st.offset}"></label>`;
function renderWords() {
  const box = $('#pane-words');
  if (!st.segments.length) { box.innerHTML = '<div class="empty">Generate captions first, then you can fix any word here.</div>'; return; }
  box.innerHTML = offHTML() + '<div class="seglist">' + st.segments.map((s, i) =>
    `<div><span class="t" data-t="${s.start}">${fmt(s.start)} ▸ jump</span><textarea dir="auto" data-seg="${i}">${esc(s.text)}</textarea></div>`).join('') + '</div>';
}
renderWords();
$('#pane-words').addEventListener('input', e => {
  if (e.target.hasAttribute('data-off')) { st.offset = +e.target.value; $('#offVal').textContent = st.offset.toFixed(2) + 's'; rebuild(); return; }
  const i = e.target.dataset.seg; if (i === undefined) return;
  const g = st.segments[i]; g.text = e.target.value; g.words = evenWords(g.start, g.end, g.text);
  rebuild();
});
$('#pane-words').addEventListener('click', e => { const t = e.target.dataset.t; if (t) video.currentTime = +t; });

/* ---------------- export ---------------- */
function save(name, text) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' })); a.download = name; a.click();
}
$('#srtBtn').addEventListener('click', () => save(st.name + '.srt', buildSRT(st.caps)));
$('#assBtn').addEventListener('click', () => save(st.name + '_styled_captions.ass', buildASS(st.caps, st.vw, st.vh)));
$('#txtBtn').addEventListener('click', () => save(st.name + '.txt', buildTXT(st.segments)));

$('#exportBtn').addEventListener('click', async () => {
  const btn = $('#exportBtn'), bar = $('#renderBar'); btn.disabled = true; video.pause();
  $('#dlLink').classList.add('hidden'); bar.classList.remove('hidden'); bar.firstElementChild.style.width = '2%';
  say('#renderMsg', 'Rendering... longer videos take longer.');
  try {
    const ass = buildASS(st.caps, st.vw, st.vh);
    const r = await fetch('/api/render', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: st.id, ass, duration: st.dur }) });
    if (!r.ok) throw new Error((await r.json()).error);
    const res = await poll('render', s => { bar.firstElementChild.style.width = Math.round((s.progress || 0) * 100) + '%'; say('#renderMsg', `Rendering... ${Math.round((s.progress || 0) * 100)}%`); });
    if (res.state === 'error') throw new Error(res.message);
    bar.firstElementChild.style.width = '100%';
    say('#renderMsg', 'Your video is ready!', 'ok');
    const dl = $('#dlLink'); dl.href = `/download/${st.id}?v=${Date.now()}`; dl.classList.remove('hidden');
  } catch (err) { say('#renderMsg', err.message, 'err'); }
  finally { btn.disabled = false; }
});

/* ---------------- resize like a picture: handle, wheel, quick bar ---------------- */
const handle = $('#handle');
function placeHandle() {
  const sr = stage.getBoundingClientRect(); let R = -1e9, B = -1e9;
  $$('#cap .bg').forEach(b => { const r = b.getBoundingClientRect(); R = Math.max(R, r.right); B = Math.max(B, r.bottom); });
  if (R === -1e9) { handle.classList.add('hidden'); return; }
  handle.classList.remove('hidden');
  handle.style.left = clamp(R - sr.left, 8, sr.width - 8) + 'px'; handle.style.top = clamp(B - sr.top, 8, sr.height - 8) + 'px';
}
let rs = null;
handle.addEventListener('pointerdown', e => {
  e.preventDefault(); e.stopPropagation(); handle.setPointerCapture(e.pointerId);
  const r = stage.getBoundingClientRect(), cx = r.left + S.x / 100 * r.width, cy = r.top + S.y / 100 * r.height;
  rs = { cx, cy, d0: Math.hypot(e.clientX - cx, e.clientY - cy) || 1, s0: S.size }; st.drag = true;
});
handle.addEventListener('pointermove', e => {
  if (!rs) return;
  S.size = clamp(Math.round(rs.s0 * Math.hypot(e.clientX - rs.cx, e.clientY - rs.cy) / rs.d0 * 10) / 10, 1, 20);
  st.tpl = -1; syncInputs();
});
handle.addEventListener('pointerup', () => { rs = null; st.drag = false; });
const bump = d => { S.size = clamp(Math.round((S.size + d) * 10) / 10, 1, 20); st.tpl = -1; syncInputs(); };
cap.addEventListener('wheel', e => { e.preventDefault(); bump(e.deltaY < 0 ? 0.3 : -0.3); }, { passive: false });
$('#sizeDn').addEventListener('click', () => bump(-0.5));
$('#sizeUp').addEventListener('click', () => bump(0.5));
$('#centerBtn').addEventListener('click', () => { S.x = 50; syncInputs(); });
syncInputs();
