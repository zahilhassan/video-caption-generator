'use strict';
/* =====================================================================
   core.js  -  pure caption logic (no DOM). Used by the live preview AND
   by the exporter, so what you see is what gets burned into the video.
   ===================================================================== */

const EMK = 0.88;                        // ASS font size -> CSS font-size ratio
const FADE = 0.15, POP = 0.16, SLIDE = 0.25, WPOP = 0.12;   // animation seconds
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

const FONTS = ['Arial', 'Arial Black', 'Impact', 'Segoe UI', 'Tahoma', 'Verdana', 'Trebuchet MS',
  'Urdu Typesetting', 'Georgia', 'Times New Roman', 'Courier New', 'Comic Sans MS', 'Calibri', 'Bahnschrift'];

const ANIMS = [
  { id: 'none',       icon: '▭', name: 'No animation' },
  { id: 'fade',       icon: '◐', name: 'Fade' },
  { id: 'pop',        icon: '✦', name: 'Pop' },
  { id: 'slide',      icon: '⇧', name: 'Slide up' },
  { id: 'typewriter', icon: '⌨', name: 'Typewriter' },
  { id: 'karaoke',    icon: '♪', name: 'Word highlight' },
  { id: 'wordpop',    icon: '①', name: 'Word by word' },
];

const BASE = {
  font: 'Arial', size: 5.5, bold: true, italic: false, upper: false,
  color: '#ffffff', hi: '#ffd400', outlineColor: '#000000', outline: 3, shadow: 1,
  box: false, boxColor: '#000000', boxOpacity: 60,
  anim: 'fade', spacing: 0, maxWords: 0, x: 50, y: 86, width: 86,
};
const T = (name, o) => ({ name, style: { ...BASE, ...o } });
const TEMPLATES = [
  T('Classic', {}),
  T('Karaoke', { font: 'Arial Black', size: 5.5, upper: true, color: '#ffffff', hi: '#00ff88', outline: 4, shadow: 2, anim: 'karaoke', maxWords: 4, y: 72, width: 80 }),
  T('Word Pop', { font: 'Impact', size: 10, bold: false, upper: true, color: '#ffffff', hi: '#ffe600', outline: 6, shadow: 2, anim: 'wordpop', y: 50, width: 80 }),
  T('Boxed', { font: 'Segoe UI', size: 4.8, color: '#ffffff', outline: 0, shadow: 0, box: true, boxColor: '#000000', boxOpacity: 70, anim: 'slide', y: 88, width: 80 }),
  T('Neon', { font: 'Trebuchet MS', size: 6.5, upper: true, color: '#00f5ff', outlineColor: '#ff00c8', outline: 3, shadow: 0, anim: 'pop', y: 80, width: 80 }),
  T('Typewriter', { font: 'Courier New', size: 5, color: '#7cff6b', outline: 0, shadow: 0, box: true, boxColor: '#000000', boxOpacity: 75, anim: 'typewriter', y: 82, width: 80 }),
  T('Cinema', { font: 'Georgia', size: 5, bold: false, italic: true, color: '#f4f1e6', outline: 2, shadow: 2, anim: 'fade', y: 90, width: 78 }),
  T('Comic', { font: 'Comic Sans MS', size: 6.2, color: '#ffe14d', outlineColor: '#1a1a1a', outline: 4.5, shadow: 2, anim: 'pop', y: 84, width: 80 }),
  T('Fire', { font: 'Arial Black', size: 6, upper: true, color: '#ffffff', hi: '#ff3b30', outline: 4, shadow: 3, anim: 'karaoke', maxWords: 3, y: 62, width: 80 })
];

// Extended preset gallery. Each card is a real, editable style preset.
const EXTRA_TEMPLATE_NAMES = [
  'Basic','Modern','Bold','Minimal','Clean','Aesthetic','Cinematic','Trending','Glow','Highlight',
  'Word Highlight','Pop Up','Pop Out','Dynamic','Podcast','Hormozi Style','MrBeast Style','Gaming',
  'Lyrics','Gradient','Rainbow','Multicolor','Outline','Shadow','Stroke','3D','Retro','Bubble',
  'Glitch','VHS','RGB','Flash','Flicker','Bounce','Shake','Wave','Elastic','Jump','Zoom','Reveal',
  'Marker','Handwritten','Script','Subtitle','Double Line','Single Line','Centered','Lower Third',
  'Animated Text','Pro Captions','Luxury','Neon Pulse','Pop Art','Impact','Highlight Box',
  'Color Block','Word by Word','Sentence by Sentence','Studio','Broadcast','Editorial','Vintage',
  'Sticker','Karaoke Highlight','Soft Shadow','Bold Highlight','Colorful Captions'
];
const EXTRA_PALETTES = [
  ['#ffffff','#ffe600','#000000'], ['#f4f7ff','#71e6ff','#111827'],
  ['#ffffff','#ffcf33','#080808'], ['#f4f4f5','#a1a1aa','#18181b'],
  ['#ffffff','#38bdf8','#111827'], ['#ffe4f1','#fb7185','#251326'],
  ['#fff7ed','#f59e0b','#171717'], ['#ffffff','#a3e635','#101820'],
  ['#f0fdff','#22d3ee','#082f49'], ['#ffffff','#facc15','#111827'],
  ['#ffffff','#00e5ff','#080808'], ['#ffffff','#ff4d6d','#111827'],
  ['#ffffff','#f97316','#111827'], ['#ffffff','#a78bfa','#111827'],
  ['#ffffff','#fbbf24','#111827'], ['#ffffff','#ffcc00','#111111'],
  ['#ffffff','#00e5ff','#090909'], ['#ffffff','#39ff14','#080808'],
  ['#fff7ed','#f472b6','#1f172a'], ['#ffffff','#a78bfa','#111827'],
  ['#ff4dff','#00e5ff','#101020'], ['#ffffff','#ff4d6d','#111827']
];
const EXTRA_FONTS = ['Arial Black','Impact','Segoe UI','Verdana','Trebuchet MS','Georgia','Courier New','Bahnschrift'];
EXTRA_TEMPLATE_NAMES.forEach((name, i) => {
  const p = EXTRA_PALETTES[i % EXTRA_PALETTES.length];
  const boxed = ['Highlight Box','Color Block','Marker','Sticker','Podcast','Broadcast'].includes(name);
  const karaoke = ['Word Highlight','Karaoke Highlight','Word by Word','Lyrics','Bold Highlight'].includes(name);
  const motion = ['Pop Up','Pop Out','Dynamic','Bounce','Shake','Wave','Elastic','Jump','Zoom','Reveal','Animated Text','Neon Pulse','Flash','Flicker'].includes(name);
  const cinematic = ['Cinematic','Luxury','Studio','Editorial','Vintage','Retro','Aesthetic'].includes(name);
  const style = {
    font: EXTRA_FONTS[i % EXTRA_FONTS.length],
    size: cinematic ? 5.1 : (['Impact','MrBeast Style','Hormozi Style','Gaming'].includes(name) ? 8 : 5.8),
    bold: !['Minimal','Clean','Luxury','Editorial','Vintage','Cinematic'].includes(name),
    italic: ['Script','Handwritten','Editorial','Lyrics'].includes(name),
    upper: ['Bold','Gaming','MrBeast Style','Hormozi Style','Impact','Neon Pulse'].includes(name),
    color: p[0], hi: p[1], outlineColor: p[2],
    outline: ['Outline','Stroke','3D','Impact','Gaming'].includes(name) ? 5 : (cinematic ? 1.5 : 2.5),
    shadow: ['Shadow','Soft Shadow','Glow','Neon Pulse','3D'].includes(name) ? 4 : 1.5,
    box: boxed, boxColor: p[2], boxOpacity: 76,
    anim: karaoke ? 'karaoke' : (motion ? (i % 2 ? 'pop' : 'slide') : (cinematic ? 'fade' : 'none')),
    maxWords: karaoke ? 3 : 0,
    x: 50, y: ['Lower Third','Subtitle','Single Line'].includes(name) ? 88 : (cinematic ? 84 : 78),
    width: ['Double Line','Single Line','Centered'].includes(name) ? 72 : 86
  };
  TEMPLATES.push(T(name, style));
});


let S = { ...TEMPLATES[0].style };       // the current style

/* ---------- captions ---------- */
function evenWords(start, end, text) {
  const ws = text.trim().split(/\s+/).filter(Boolean);
  const d = (end - start) / Math.max(1, ws.length);
  return ws.map((w, i) => ({ w, s: start + i * d, e: start + (i + 1) * d }));
}

/** segments -> captions (optionally split into short chunks of `mw` words) */
function buildCaptions(segments, mw) {
  const caps = [];
  for (const g of segments) {
    const words = (g.words && g.words.length) ? g.words : evenWords(g.start, g.end, g.text);
    if (!words.length) continue;
    if (!mw) { caps.push({ start: g.start, end: g.end, words }); continue; }
    for (let i = 0; i < words.length; i += mw) {
      const part = words.slice(i, i + mw);
      caps.push({ start: part[0].s, end: part[part.length - 1].e, words: part });
    }
  }
  caps.forEach((c, i) => {
    const nx = caps[i + 1];
    let end = c.end + (mw ? 0.15 : 0);
    if (nx) end = Math.min(end, nx.start);
    c.end = Math.max(end, c.start + 0.15);
  });
  return caps;
}

const disp = c => c.words.map((w, i) => ({ i, w: S.upper ? w.w.toUpperCase() : w.w, s: w.s, e: w.e }));

/** the time slice during which each word is "the current word" */
function wordSpans(c) {
  const n = c.words.length;
  return c.words.map((w, i) => ({ i, from: i ? w.s : c.start, to: i < n - 1 ? c.words[i + 1].s : c.end }))
    .filter(s => s.to - s.from > 0.01);
}

/** greedy line wrapping - identical in the preview and in the exported video */
function wrapLines(words, W, H) {
  const fontPx = S.size / 100 * H * EMK;
  const cw = S.upper ? 0.68 : (S.bold ? 0.56 : 0.52);
  const maxChars = Math.max(6, Math.floor(S.width / 100 * W / (fontPx * cw)));
  const lines = [[]];
  let len = 0;
  for (const w of words) {
    const cur = lines[lines.length - 1];
    if (cur.length && len + 1 + w.w.length > maxChars) { lines.push([]); len = 0; }
    const line = lines[lines.length - 1];
    len += (line.length ? 1 : 0) + w.w.length;
    line.push(w);
  }
  return lines;
}

const flatText = lines => lines.map(l => l.map(w => w.w).join(' ')).join('\n');

/** time at which every character of the flat text appears (typewriter) */
function charTimes(lines) {
  const t = [];
  let last = 0;
  lines.forEach((l, li) => l.forEach((w, wi) => {
    if (wi > 0 || li > 0) t.push(Math.max(last, w.s));
    const d = Math.max(0.01, w.e - w.s);
    for (let k = 0; k < w.w.length; k++) { last = Math.max(last, w.s + d * k / w.w.length); t.push(last); }
  }));
  return t;
}

/** what the preview should draw for caption `c` at video time `t` */
function frameAt(c, t, W, H) {
  const local = t - c.start, dur = c.end - c.start;
  let words = disp(c), o = 1, sc = 1, dy = 0, hi = -1, n = null;
  switch (S.anim) {
    case 'fade':  o = Math.min(1, local / FADE, (dur - local) / FADE); break;
    case 'pop':   sc = 0.6 + 0.4 * clamp(local / POP, 0, 1); o = Math.min(1, local / 0.08, (dur - local) / 0.08); break;
    case 'slide': dy = (1 - clamp(local / SLIDE, 0, 1)) * 0.06 * H; o = Math.min(1, local / 0.12, (dur - local) / 0.12); break;
    case 'karaoke': { const sp = wordSpans(c).find(s => t >= s.from && t < s.to); hi = sp ? sp.i : -1; break; }
    case 'wordpop': {
      const sp = wordSpans(c).find(s => t >= s.from && t < s.to);
      if (!sp) return null;
      words = [words[sp.i]];
      sc = 0.7 + 0.3 * clamp((t - sp.from) / WPOP, 0, 1);
      break;
    }
  }
  const lines = wrapLines(words, W, H);
  if (S.anim === 'typewriter') n = charTimes(lines).filter(x => x <= t).length;
  return { o: clamp(o, 0, 1), sc, dy, lines, hi, n };
}

/* ---------- ASS (the format FFmpeg burns into the video) ---------- */
const hx = n => Math.round(n).toString(16).padStart(2, '0').toUpperCase();
const assColor = (hex, alpha = 0) => { const h = hex.replace('#', ''); return `&H${hx(alpha)}${h.slice(4, 6)}${h.slice(2, 4)}${h.slice(0, 2)}`.toUpperCase(); };
const assTag = hex => { const h = hex.replace('#', ''); return `&H${h.slice(4, 6)}${h.slice(2, 4)}${h.slice(0, 2)}&`.toUpperCase(); };
const aesc = s => s.replace(/[{}\\]/g, '').replace(/\n/g, '\\N');
function assTime(t) {
  const cs = Math.round(Math.max(0, t) * 100);
  const h = Math.floor(cs / 360000), m = Math.floor(cs % 360000 / 6000), s = Math.floor(cs % 6000 / 100), c = cs % 100;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(c).padStart(2, '0')}`;
}

function buildASS(caps, W, H) {
  const sizePx = Math.round(S.size / 100 * H);
  const outline = S.outline * H / 1080, shadow = S.shadow * H / 1080;
  const pad = S.size / 100 * H * 0.22;
  const boxAlpha = Math.round(255 * (1 - S.boxOpacity / 100));
  const style = ['Default', S.font, sizePx, assColor(S.color), assColor(S.hi),
    S.box ? assColor(S.boxColor, boxAlpha) : assColor(S.outlineColor), '&H80000000',
    S.bold ? -1 : 0, S.italic ? -1 : 0, 0, 0, 100, 100, ((S.spacing || 0) * H / 1080).toFixed(1), 0,
    S.box ? 3 : 1, (S.box ? pad : outline).toFixed(1), S.box ? 0 : shadow.toFixed(1), 5, 10, 10, 10, 1].join(',');

  const X = Math.round(S.x / 100 * W), Y = Math.round(S.y / 100 * H);
  const head = `an5\\q2`;
  const ev = (s, e, tags, text) => `Dialogue: 0,${assTime(s)},${assTime(e)},Default,,0,0,0,,{${tags}}${text}`;
  const plain = lines => lines.map(l => l.map(w => aesc(w.w)).join(' ')).join('\\N');
  const out = [];

  for (const c of caps) {
    const words = disp(c);
    if (S.anim === 'wordpop') {
      for (const sp of wordSpans(c)) {
        out.push(ev(sp.from, sp.to, `\\${head}\\pos(${X},${Y})\\fscx70\\fscy70\\t(0,${WPOP * 1000},\\fscx100\\fscy100)`,
          plain(wrapLines([words[sp.i]], W, H))));
      }
      continue;
    }
    const lines = wrapLines(words, W, H);
    if (S.anim === 'karaoke') {
      for (const sp of wordSpans(c)) {
        const txt = lines.map(l => l.map(w => w.i === sp.i
          ? `{\\1c${assTag(S.hi)}}${aesc(w.w)}{\\1c${assTag(S.color)}}` : aesc(w.w)).join(' ')).join('\\N');
        out.push(ev(sp.from, sp.to, `\\${head}\\pos(${X},${Y})`, txt));
      }
    } else if (S.anim === 'typewriter') {
      const flat = flatText(lines), times = charTimes(lines);
      const marks = [...new Set(times.map(x => Math.max(x, c.start)))].sort((a, b) => a - b);
      marks.forEach((m, j) => {
        const end = j + 1 < marks.length ? marks[j + 1] : c.end;
        if (end - m < 0.005) return;
        const n = times.filter(x => x <= m).length;
        const hidden = flat.slice(n);
        out.push(ev(m, end, `\\${head}\\pos(${X},${Y})`, aesc(flat.slice(0, n)) + (hidden ? `{\\alpha&HFF&}${aesc(hidden)}` : '')));
      });
    } else {
      let tags = `\\${head}\\pos(${X},${Y})`;
      if (S.anim === 'fade') tags += `\\fad(${FADE * 1000},${FADE * 1000})`;
      if (S.anim === 'pop') tags += `\\fad(80,80)\\fscx60\\fscy60\\t(0,${POP * 1000},\\fscx100\\fscy100)`;
      if (S.anim === 'slide') tags = `\\${head}\\move(${X},${Y + Math.round(0.06 * H)},${X},${Y},0,${SLIDE * 1000})\\fad(120,120)`;
      out.push(ev(c.start, c.end, tags, plain(lines)));
    }
  }

  return `[Script Info]
ScriptType: v4.00+
PlayResX: ${W}
PlayResY: ${H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: ${style}

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
${out.join('\n')}
`;
}

/* ---------- plain text exports ---------- */
const srtTime = t => assTime(t).replace(/^(\d+):/, (_, h) => String(h).padStart(2, '0') + ':').replace('.', ',') + '0';
function buildSRT(caps) {
  return caps.map((c, i) => `${i + 1}\n${srtTime(c.start)} --> ${srtTime(c.end)}\n${c.words.map(w => w.w).join(' ')}\n`).join('\n');
}
const buildTXT = segments => segments.map(s => s.text.trim()).join('\n');

if (typeof module !== 'undefined') module.exports = { buildCaptions, buildASS, buildSRT, frameAt, TEMPLATES, setStyle: o => { S = { ...o }; } };
