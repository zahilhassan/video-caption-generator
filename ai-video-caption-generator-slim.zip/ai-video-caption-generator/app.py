"""Caption Generator - local web app. Start it with run.bat (Windows)."""
import os
import sys
import re
import time
import shutil
import secrets
import subprocess
import threading
import webbrowser
from collections import defaultdict, deque
from pathlib import Path

BASE = Path(__file__).resolve().parent

# ---- Everything the app needs ships inside this folder (no installs at start-up) ----
if (BASE / "libs").is_dir():
    sys.path.insert(0, str(BASE / "libs"))          # pre-installed Python packages
if (BASE / "ffmpeg_bin").is_dir():
    os.environ["PATH"] = str(BASE / "ffmpeg_bin") + os.pathsep + os.environ.get("PATH", "")
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
os.environ.setdefault("NUMBA_CACHE_DIR", str(DATA / "numba_cache"))

from flask import (Flask, abort, g, jsonify, redirect, request, send_file,  # noqa: E402
                   send_from_directory, Response)

from transcriber import burn_ass, transcribe_video                           # noqa: E402

WORK = BASE / "workspace"
STATIC = BASE / "static"


# ============================================================ configuration
def load_config():
    cfg = {}
    path = BASE / "config.env"
    if path.is_file():
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            cfg[key.strip()] = value.strip().strip('"').strip("'")
    for key in list(cfg):                         # real environment variables win
        cfg[key] = os.environ.get(key, cfg[key])
    return cfg


CFG = load_config()
try:
    PORT = int(CFG.get("PORT", "8000"))
except ValueError:
    PORT = 8000
ORIGIN = f"http://localhost:{PORT}"


# ============================================================ app
app = Flask(__name__, static_folder=None)
app.config.update(MAX_CONTENT_LENGTH=4 * 1024 ** 3)

LOCAL_USER = "local"       # no sign-in: everything belongs to this one local workspace

JOBS = {}                  # video id -> job dict (always has "owner")
VID_RE = re.compile(r"^[0-9a-f]{16}$")
VIDEO_EXT = {".mp4", ".m4v", ".mov", ".webm", ".mkv", ".avi", ".mpg", ".mpeg", ".wmv", ".flv", ".3gp", ".ts"}
BROWSER_OK = {".mp4", ".m4v", ".webm", ".mov"}
MIME = {".mp4": "video/mp4", ".m4v": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime"}
MODELS = {"tiny", "base", "small", "medium", "turbo"}
TASKS = {"transcribe", "translate"}
LANG_RE = re.compile(r"^[a-z]{2,3}$")


class Limiter:
    """Tiny in-memory rate limiter."""
    def __init__(self):
        self.hits = defaultdict(deque)
        self.lock = threading.Lock()

    def allow(self, key, limit, per_seconds):
        now = time.time()
        with self.lock:
            q = self.hits[key]
            while q and now - q[0] > per_seconds:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            return True


limiter = Limiter()


def err(message, code=400):
    return jsonify(error=message), code


def safe_text(exc):
    """Error text for the page, without local folder paths."""
    text = str(exc)
    for p in {str(BASE), str(BASE).replace("\\", "/")}:
        text = text.replace(p, ".")
    return text[-1500:]


def clean_name(filename):
    stem = Path(filename).stem
    stem = re.sub(r"[^\w\-. ()]", "_", stem, flags=re.UNICODE).strip(" .")
    return (stem or "video")[:80]


# ============================================================ request guards
@app.before_request
def guard():
    # 1) Only answer to our own address (stops DNS-rebinding attacks from other websites)
    host = (request.host or "").lower()
    if host == f"127.0.0.1:{PORT}" and request.method == "GET":
        return redirect(ORIGIN + request.full_path.rstrip("?"), 302)
    if host != f"localhost:{PORT}":
        abort(400)

    # 2) Block changing requests that come from another website
    if request.method not in ("GET", "HEAD", "OPTIONS") and request.path.startswith("/api/"):
        origin = request.headers.get("Origin")
        if origin and origin != ORIGIN:
            return err("Blocked: request came from another site.", 403)

    g.uid = LOCAL_USER


@app.after_request
def secure_headers(resp):
    h = resp.headers
    if "Content-Security-Policy" not in h:      # (/media sets its own, stricter one)
        h["Content-Security-Policy"] = ("default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                                        "img-src 'self' data:; media-src 'self' blob:; "
                                        "connect-src 'self'; font-src 'self' data:; form-action 'self'; "
                                        "base-uri 'none'; frame-ancestors 'none'; object-src 'none'")
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "DENY"
    h["Referrer-Policy"] = "no-referrer"
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=()"
    h["Cross-Origin-Opener-Policy"] = "same-origin"
    h["Cross-Origin-Resource-Policy"] = "same-origin"
    h["Cache-Control"] = "no-store"
    return resp


# ============================================================ pages
@app.get("/")
def index():
    return send_from_directory(STATIC, "index.html")


@app.get("/static/<path:name>")
def static_files(name):
    return send_from_directory(STATIC, name)


@app.get("/favicon.ico")
def favicon():
    return Response(status=204)


# ============================================================ jobs (every job belongs to one user)
def user_job(vid):
    job = JOBS.get(vid) if VID_RE.match(vid or "") else None
    if not job or job["owner"] != g.uid:
        abort(404)
    return job


@app.post("/api/upload")
def upload():
    if not limiter.allow(("upload", g.uid), 30, 3600):
        return err("Too many uploads. Please wait a little.", 429)
    f = request.files.get("video")
    if not f or not f.filename:
        return err("No video received.")
    ext = Path(f.filename).suffix.lower()
    if ext not in VIDEO_EXT:
        return err("This file type is not supported. Please use MP4, MOV, MKV, AVI or WEBM.")
    vid = secrets.token_hex(8)
    folder = WORK / g.uid / vid
    folder.mkdir(parents=True, exist_ok=True)
    src = folder / f"input{ext}"
    f.save(src)
    preview = src
    if ext not in BROWSER_OK:  # make a browser-playable copy just for the preview
        preview = folder / "preview.mp4"
        try:
            done = subprocess.run(
                ["ffmpeg", "-y", "-i", str(src), "-c:v", "libx264", "-preset", "ultrafast", "-crf", "27",
                 "-pix_fmt", "yuv420p", "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-c:a", "aac",
                 "-movflags", "+faststart", str(preview)],
                capture_output=True, text=True, timeout=3600)
            ok, detail = done.returncode == 0, done.stderr[-400:]
        except subprocess.TimeoutExpired:
            ok, detail = False, "timed out"
        if not ok:
            shutil.rmtree(folder, ignore_errors=True)
            return err("Could not read this video: " + safe_text(detail))
    name = clean_name(f.filename)
    JOBS[vid] = {"owner": g.uid, "src": str(src), "preview": str(preview), "name": name, "created": time.time()}
    return jsonify(id=vid, name=name)


@app.get("/media/<vid>")
def media(vid):
    job = user_job(vid)
    path = Path(job["preview"])
    resp = send_file(path, mimetype=MIME.get(path.suffix.lower(), "video/mp4"), conditional=True)
    resp.headers["Content-Security-Policy"] = "sandbox"
    return resp


def _run_transcribe(job, model, language, task):
    state = job["transcribe"]
    try:
        segments, lang = transcribe_video(job["src"], model, language, task,
                                          on_status=lambda m: state.update(message=m))
        state.update(state="done", segments=segments, language=lang, message="Captions ready")
    except Exception as exc:  # shown to the user in the page
        state.update(state="error", message=safe_text(exc))


@app.post("/api/transcribe")
def transcribe():
    data = request.get_json(silent=True) or {}
    job = user_job(str(data.get("id", "")))
    model, task = data.get("model", "small"), data.get("task", "transcribe")
    language = data.get("language") or None
    if language == "auto":
        language = None
    if model not in MODELS or task not in TASKS or (language and not LANG_RE.match(str(language))):
        return err("Invalid options.")
    if job.get("transcribe", {}).get("state") == "running":
        return err("Already working on this video.", 409)
    if not limiter.allow(("transcribe", g.uid), 30, 3600):
        return err("Too many requests. Please wait a little.", 429)
    job["transcribe"] = {"state": "running", "message": "Starting..."}
    threading.Thread(target=_run_transcribe, daemon=True, args=(job, model, language, task)).start()
    return jsonify(ok=True)


def _run_render(job, ass, duration):
    state = job["render"]
    try:
        job["out"] = burn_ass(job["src"], ass, "captioned.mp4", duration,
                              on_progress=lambda p: state.update(progress=p))
        state.update(state="done", progress=1.0, message="Your video is ready")
    except Exception as exc:
        state.update(state="error", message=safe_text(exc))


@app.post("/api/render")
def render():
    data = request.get_json(silent=True) or {}
    job = user_job(str(data.get("id", "")))
    ass = data.get("ass", "")
    if not isinstance(ass, str) or not ass.strip() or len(ass) > 8_000_000:
        return err("Invalid caption data.")
    try:
        duration = min(max(float(data.get("duration") or 0), 0.0), 86400.0)
    except (TypeError, ValueError):
        return err("Invalid duration.")
    if job.get("render", {}).get("state") == "running":
        return err("Already rendering this video.", 409)
    if not limiter.allow(("render", g.uid), 30, 3600):
        return err("Too many requests. Please wait a little.", 429)
    job["render"] = {"state": "running", "progress": 0.0, "message": "Rendering video..."}
    threading.Thread(target=_run_render, daemon=True, args=(job, ass, duration)).start()
    return jsonify(ok=True)


@app.get("/api/status/<vid>/<kind>")
def status(vid, kind):
    job = user_job(vid)
    if kind not in ("transcribe", "render"):
        abort(404)
    return jsonify(job.get(kind, {"state": "idle"}))


@app.get("/download/<vid>")
def download(vid):
    job = user_job(vid)
    if not job.get("out"):
        return "Not ready", 404
    return send_file(job["out"], as_attachment=True, download_name=f"{job['name']}_captioned.mp4")


# ============================================================ housekeeping
def _clean_old_files():
    WORK.mkdir(exist_ok=True)
    cutoff = time.time() - 24 * 3600
    for user_dir in WORK.iterdir():
        if not user_dir.is_dir():
            continue
        for d in user_dir.iterdir():
            if d.is_dir() and d.stat().st_mtime < cutoff:
                shutil.rmtree(d, ignore_errors=True)
                JOBS.pop(d.name, None)
        if not any(user_dir.iterdir()):
            user_dir.rmdir()


def _cleaner_loop():
    while True:
        time.sleep(3600)
        try:
            _clean_old_files()
        except Exception as exc:
            print("[cleanup]", exc)


def main():
    _clean_old_files()
    if shutil.which("ffmpeg") is None:
        print("[ERROR] FFmpeg was not found (ffmpeg_bin\\ffmpeg.exe is missing). Delete the ffmpeg_bin folder and run run.bat again.")
        sys.exit(1)
    threading.Thread(target=_cleaner_loop, daemon=True).start()
    print(f"Caption Generator is running at {ORIGIN}   (close this window to stop it)")
    if "--no-browser" not in sys.argv:
        threading.Timer(1.5, lambda: webbrowser.open(ORIGIN)).start()
    from waitress import serve
    serve(app, host="127.0.0.1", port=PORT, threads=8, max_request_body_size=4 * 1024 ** 3,
          clear_untrusted_proxy_headers=True, ident="caption-generator")


if __name__ == "__main__":
    main()
