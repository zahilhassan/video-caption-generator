@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Caption Generator - Created by Zahil Hassan

echo ==============================================
echo   Caption Generator - Created by Zahil Hassan
echo ==============================================
echo.

REM ---------- 1. Find Python (3.10 - 3.12) ----------
set "PY="
for %%V in (3.11 3.12 3.10) do (
    if not defined PY (
        py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
    )
)
if not defined PY (
    python -c "import sys; sys.exit(0 if (3,10)<=sys.version_info[:2]<=(3,12) else 1)" >nul 2>&1 && set "PY=python"
)
if not defined PY goto :nopython

REM ---------- 2. Create the virtual environment (first run only) ----------
if not exist "venv\Scripts\python.exe" (
    echo [1/3] Creating Python environment...
    %PY% -m venv venv
    if errorlevel 1 goto :fail
)

REM ---------- 3. Download FFmpeg (first run only) ----------
if not exist "ffmpeg_bin\ffmpeg.exe" (
    echo [2/3] Downloading FFmpeg ^(about 90 MB^)...
    if not exist "ffmpeg_bin" mkdir "ffmpeg_bin"
    if exist "ffmpeg_tmp" rmdir /s /q "ffmpeg_tmp"
    curl.exe -L --fail -o "ffmpeg_tmp.zip" "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
    if errorlevel 1 (
        echo First mirror failed, trying another one...
        curl.exe -L --fail -o "ffmpeg_tmp.zip" "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
        if errorlevel 1 goto :fail
    )
    powershell -NoProfile -Command "Expand-Archive -LiteralPath 'ffmpeg_tmp.zip' -DestinationPath 'ffmpeg_tmp' -Force"
    for /d %%D in ("ffmpeg_tmp\ffmpeg-*") do copy /y "%%D\bin\ffmpeg.exe" "ffmpeg_bin\ffmpeg.exe" >nul
    rmdir /s /q "ffmpeg_tmp"
    del /q "ffmpeg_tmp.zip"
    if not exist "ffmpeg_bin\ffmpeg.exe" goto :fail
)

REM ---------- 4. Install Python packages (first run only - this takes a while) ----------
if not exist "venv\.deps_installed" (
    echo [3/3] Installing AI packages ^(PyTorch, Whisper, Flask...^).
    echo       First time only: about 5-15 minutes and ~2 GB of download. Please wait...
    "venv\Scripts\python.exe" -m pip install --upgrade pip
    "venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto :fail
    echo done> "venv\.deps_installed"
)

REM ---------- 5. Microsoft Visual C++ runtime (needed by PyTorch; most PCs already have it) ----------
if not exist "%SystemRoot%\System32\msvcp140.dll" (
    echo [ERROR] "Microsoft Visual C++ Runtime" is missing on this PC.
    echo Install it once from: https://aka.ms/vs/17/release/vc_redist.x64.exe
    echo Then double-click run.bat again.
    pause
    exit /b 1
)

REM ---------- 6. Start the app (it opens your browser by itself) ----------
echo.
echo Starting... your browser opens in a moment.
echo Keep this window open while using the app. Close it to stop the app.
echo.
"venv\Scripts\python.exe" app.py

echo.
echo App stopped.
pause
exit /b 0

:nopython
echo [ERROR] Python 3.10, 3.11 or 3.12 was not found on this PC.
echo.
where winget >nul 2>&1
if not errorlevel 1 (
    echo Trying to install Python 3.11 automatically with winget...
    winget install -e --id Python.Python.3.11 --accept-package-agreements --accept-source-agreements
    echo.
    echo If the install finished, CLOSE this window and double-click run.bat again.
) else (
    echo Please install Python 3.11 from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add python.exe to PATH" in the installer, then run run.bat again.
)
pause
exit /b 1

:fail
echo.
echo [ERROR] Setup failed. Check your internet connection and run run.bat again.
echo It will continue from where it stopped.
pause
exit /b 1
