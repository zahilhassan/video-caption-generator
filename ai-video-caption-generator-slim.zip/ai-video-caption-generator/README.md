# Caption Generator - AI Video Caption Generator

Upload a video, let Whisper AI write the captions, design them live (templates, fonts, colors,
animations, drag-to-position) and export a new MP4 with the captions burned in.

## Install & Run (Windows 10/11, 64-bit)

1. Click **Code > Download ZIP** on GitHub (or `git clone`) and extract it. Use a short folder such as `D:\CaptionGenerator`.
2. Double-click **`run.bat`**.
3. Your browser opens the app automatically - no sign-in needed.

> ### ⏳ First run takes time (5-15 minutes)
> The repository is tiny on purpose, so **`run.bat` downloads and installs everything on your PC the first time**:
> - a Python virtual environment (`venv/`)
> - FFmpeg (~90 MB, `ffmpeg_bin/`)
> - PyTorch + Whisper + Flask (~2 GB of downloads)
>
> Please keep the window open and wait until the browser opens. You need an internet connection for this step.
> **Every next start takes only a few seconds** - nothing is downloaded again.

### Requirements
- Windows 10/11 (64-bit)
- Python **3.10, 3.11 or 3.12** - if it is missing, `run.bat` tries to install Python 3.11 with `winget`
  (otherwise install it from [python.org](https://www.python.org/downloads/) and tick **"Add python.exe to PATH"**)
- ~5 GB free disk space
- Microsoft Visual C++ Runtime ([download](https://aka.ms/vs/17/release/vc_redist.x64.exe)) - most PCs already have it

The Whisper AI model is also downloaded once, the first time you press **"Generate captions"**
(tiny 75 MB, small 460 MB). It is saved in `models/`.

### Troubleshooting
- Setup stopped / internet dropped? Just run `run.bat` again - it continues where it stopped.
- Want a clean reinstall? Delete the `venv` and `ffmpeg_bin` folders and run `run.bat` again.

## Security built in
- Host check against DNS rebinding; Origin check on all actions
- Strict Content-Security-Policy, no-sniff, no-framing, no-referrer
- Upload type whitelist, input validation, rate limits, one job at a time per video, no shell commands
- Server listens on 127.0.0.1 only; files older than 24 h are deleted automatically

## Features
- Fully custom HTML / CSS / JavaScript interface (Flask backend)
- 9 templates, 13 fonts, text/outline/highlight/box colors, shadow, bold/italic/uppercase
- 7 animations: none, fade, pop, slide up, typewriter, word highlight, word-by-word
- Drag captions anywhere on the video + position/width sliders
- Edit any word after the AI writes it; export SRT / TXT or the finished MP4
- Languages: Urdu, Hindi, English, Arabic and many more; optional translate to English

## Files
- `run.bat` - one-click installer + launcher  - `config.env` - optional settings (port)
- `requirements.txt` - Python packages (installed automatically)
- `app.py` - server  - `transcriber.py` - Whisper + FFmpeg
- `static/` - interface (`index.html`, `style.css`, `core.js`, `app.js`)

Created by Zahil Hassan
