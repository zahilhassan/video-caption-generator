"""Speech-to-text (Whisper) and caption burning (FFmpeg) helpers."""
from pathlib import Path
import subprocess
import tempfile
import threading

BASE = Path(__file__).resolve().parent
MODELS_DIR = BASE / "models"   # AI models are stored next to the app (downloaded once, or copy them here)
_models = {}
_model_lock = threading.Lock()


def _get_model(name):
    import whisper  # imported lazily so the web page starts instantly
    with _model_lock:
        if name not in _models:
            _models[name] = whisper.load_model(name, download_root=str(MODELS_DIR))
        return _models[name]


def extract_audio(video_path, audio_path):
    """Extract mono 16 kHz WAV audio from the video."""
    cmd = ["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1", "-ar", "16000",
           "-acodec", "pcm_s16le", str(audio_path)]
    done = subprocess.run(cmd, capture_output=True, text=True)
    if done.returncode != 0:
        raise RuntimeError("FFmpeg could not read the audio:\n" + (done.stderr or "")[-1500:])


def transcribe_video(video_path, model_name="small", language=None, task="transcribe", on_status=None):
    """Returns a list of segments: {start, end, text, words:[{w, s, e}]}."""
    say = on_status or (lambda msg: None)
    if not Path(video_path).is_file():
        raise FileNotFoundError("Video file not found.")

    say(f"Loading AI model '{model_name}' (the first time it downloads, please wait)...")
    model = _get_model(model_name)

    with tempfile.TemporaryDirectory() as tmp:
        wav = str(Path(tmp) / "audio.wav")
        say("Extracting audio from the video...")
        extract_audio(video_path, wav)
        say("Listening to the speech and writing captions... (this can take a few minutes)")
        try:
            import torch
            fp16 = bool(torch.cuda.is_available())
        except Exception:
            fp16 = False
        result = model.transcribe(wav, language=language, task=task, word_timestamps=True,
                                  verbose=None, fp16=fp16)

    segments = []
    for seg in result.get("segments", []):
        words = []
        for w in seg.get("words", []) or []:
            text = (w.get("word") or "").strip()
            if text:
                words.append({"w": text, "s": round(float(w["start"]), 3), "e": round(float(w["end"]), 3)})
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        segments.append({"start": round(float(seg["start"]), 3), "end": round(float(seg["end"]), 3),
                         "text": text, "words": words})
    return segments, result.get("language", "")


def burn_ass(video_path, ass_text, out_name="captioned.mp4", duration=0.0, on_progress=None):
    """Burn an ASS subtitle script into the video. Runs inside the video folder with
    relative names so Windows paths never break FFmpeg's filter syntax."""
    video = Path(video_path)
    work = video.parent
    (work / "captions.ass").write_text(ass_text, encoding="utf-8")
    cmd = ["ffmpeg", "-y", "-i", video.name,
           "-vf", "ass=captions.ass,scale=trunc(iw/2)*2:trunc(ih/2)*2",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
           "-progress", "pipe:1", "-nostats", "-loglevel", "error", out_name]
    log_path = work / "ffmpeg.log"
    with open(log_path, "w", encoding="utf-8") as log:
        proc = subprocess.Popen(cmd, cwd=str(work), stdout=subprocess.PIPE, stderr=log, text=True)
        for line in proc.stdout:
            if on_progress and duration > 0 and line.startswith(("out_time_us=", "out_time_ms=")):
                try:
                    seconds = int(line.split("=")[1]) / 1_000_000
                    on_progress(min(0.99, seconds / duration))
                except ValueError:
                    pass
        proc.wait()
    if proc.returncode != 0:
        tail = log_path.read_text(encoding="utf-8", errors="ignore")[-1500:]
        raise RuntimeError("FFmpeg could not create the video:\n" + tail)
    return str(work / out_name)
